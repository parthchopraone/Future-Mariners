IMAGE REPLACEMENT

1. Upload this ZIP as an Overleaf project (or extract all files into one folder).
2. Open Modern_Power_Converters_IA4_Full_Report.tex.
3. Each figure uses a standard includegraphics command.
4. Easiest: upload your real image using the SAME filename as its placeholder and overwrite it.
5. Alternatively, use your editor image controls to choose the new file; in source, change only the filename inside includegraphics.
6. Keep filenames case-sensitive. Captions remain in the LaTeX source.

flyback_input_model.png : Averaged flyback model: input-voltage step
uncompensated_bode.png : Uncompensated plant Bode plot
compensated_bode.png : Compensated and uncompensated Bode comparison
input_step_waveforms.png : Input-step traces: input voltage, output voltage, load current
flyback_load_model.png : Averaged flyback model: load-resistance step
load_step_waveforms.png : Load-step traces: input voltage, output voltage, load current
resonant_circuit.png : Full-bridge series resonant converter circuit
resonant_waveforms.png : Resonant tank and ZVS / ZCS switching waveforms